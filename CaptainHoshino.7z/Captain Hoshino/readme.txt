Put the folder "bank"  under World_of_Warships\bin\"folder with biggest number"\res_mods\
In game: settings-audio-voiceover modifications choose Hoshino and all set.

先生～。せっかくなんだし、のんびり行こうよ～





Original maker of the mod:Bilibili@兔喷喷
voice resource from GameKee